#!/usr/bin/env python
# coding: utf-8

# 导入所需的模块
import igraph
from igraph import plot
import pandas as pd
import time

# 读入数据
data = pd.read_csv('data/influence_data_reid.csv')

# 生成图的边, 元组列表, 每个元组为两顶点表示一条边
edges = []
for i in list(map(tuple, data[['inf_id', 'flw_id']].values)):
    tp = (i[0], i[1])
    if tp in edges or tp[::-1] in edges:
        continue
    else:
        edges.append(tp)

# 通过边edges生成Graph图对象
g = igraph.Graph(edges)
# fastgreedy算法
g_ifmp = g.community_fastgreedy()
g2 = g_ifmp.as_clustering(n=16)
# 修改图形样式, 输出图片
visual_style = {}
visual_style["vertex_size"] = 10
visual_style["layout"] = g.layout("drl")
visual_style["margin"] = 80
out = plot(g2, **visual_style)
out.save('res.eps')
